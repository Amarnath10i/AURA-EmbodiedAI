"""
env/warehouse.py — the embodied environment (Generation 1).

Design contract (from the AURA v2 spec):
  * The robot knows ONLY 10 primitive actions. There is no "open door" or
    "use chair" action anywhere in this file's API.
  * Objects have hidden physics (mass, friction, size, special behaviour)
    living exclusively inside the engine.
  * Observations carry NO object labels: rgb + depth + proprioception only.
  * Higher-level behaviour (unlocking doors with keys, pressing switches by
    throwing pipes, weighing down pressure plates with boxes, using the
    low-friction ramp zone to move fast) must EMERGE from interaction.

Hidden mechanics the agent can discover:
  door:   push while a key is in inventory  -> unlocks & opens (key consumed)
          push when unlocked                -> opens
  switch: ANY body touching it (robot or a pushed object) opens its linked door
  plate:  any object with mass > 2 resting on it opens its linked door
  ramp:   robot inside the zone moves 1.6x faster
  battery: grab -> +40 energy (consumed)

Primitive actions:
  0 forward  1 backward  2 rotate_left  3 rotate_right
  4 push     5 pull      6 grab         7 release      8 wait  9 observe
"""

from __future__ import annotations
import math
import numpy as np
import pymunk
from PIL import Image, ImageDraw

from .physics import PhysicsWorld
from .objects import CATALOGUE, ROBOT_COLOR, FLOOR_COLOR, DOOR_OPEN_COLOR

ACTIONS = ["forward", "backward", "rotate_left", "rotate_right",
           "push", "pull", "grab", "release", "wait", "observe"]
N_ACTIONS = len(ACTIONS)

W = H = 480               # world size in pixels
ROBOT_R = 14
REACH = 46                # interaction reach in front of the robot
DEPTH_RAYS = 64
DEPTH_FOV = math.pi       # 180-degree forward fan


class Warehouse:
    def __init__(self, seed: int = 0, task: dict | None = None,
                 obs_size: int = 96, max_steps: int = 600,
                 layout_seed: int | None = None):
        self.rng = np.random.default_rng(seed)
        self.layout_rng = np.random.default_rng(
            seed if layout_seed is None else layout_seed)
        self.obs_size = obs_size
        self.max_steps = max_steps
        self.task = task or {"goal": "explore"}
        self.reset()

    # =============================== layout ================================ #
    def reset(self, seed: int | None = None):
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self.pw = PhysicsWorld()
        self.t = 0
        self.energy = 100.0
        self.inventory: list[str] = []      # object kinds carried
        self.grab_joint = None              # (joint, oid) while dragging
        self.events: list[str] = []
        self._door_links: dict[str, str] = {}   # trigger oid -> door oid

        self._build_layout()
        self._place_task_objects()

        self.robot = self.pw.space.static_body  # placeholder replaced below
        body = pymunk.Body(10.0, pymunk.moment_for_circle(10.0, 0, ROBOT_R))
        body.position = tuple(self._spawn("left"))
        shape = pymunk.Circle(body, ROBOT_R)
        shape.friction = 0.6
        self.pw.space.add(body, shape)
        self.robot, self.robot_shape = body, shape
        self.theta = float(self.rng.uniform(-math.pi, math.pi))

        return self._observe(), self._info(interaction=None)

    def _build_layout(self):
        m = 8
        self.pw.add_wall((m, m), (W - m, m))
        self.pw.add_wall((W - m, m), (W - m, H - m))
        self.pw.add_wall((W - m, H - m), (m, H - m))
        self.pw.add_wall((m, H - m), (m, m))
        # dividing wall with two gaps (top gap gets a door)
        x = W / 2
        self.pw.add_wall((x, m), (x, 130))
        self.pw.add_wall((x, 190), (x, 330))
        self.pw.add_wall((x, 390), (x, H - m))
        self.gap_top = (x, 160)     # door slot
        self.gap_bot = (x, 360)     # door slot 2

        # shelves along walls
        for cy in (90, 240, 390):
            self.pw.add("shelf", (70, cy))
            self.pw.add("shelf", (W - 70, cy))

    def _place_task_objects(self):
        rng = self.layout_rng
        goal = self.task.get("goal", "explore")

        # movable furniture, both rooms
        self.pw.add("table", (150, 300), angle=rng.uniform(0, math.pi))
        for pos in [(180, 120), (120, 400)]:
            self.pw.add("chair", pos, angle=rng.uniform(0, math.pi))
        for pos in [(330, 120), (300, 420), (200, 220)]:
            self.pw.add("box", pos, angle=rng.uniform(0, math.pi))
        self.pw.add("pipe", (300, 300), angle=rng.uniform(0, math.pi))
        self.pw.add("ramp", (150, 200))           # speed zone, room A

        # doors on the dividing-wall gaps
        d_top = self.pw.add("door", self.gap_top)
        self.pw.objects[d_top]["state"]["locked"] = bool(
            self.task.get("lock_top_door", False))
        self.pw.objects[d_top]["state"]["open"] = not self.task.get(
            "close_top_door", True)
        d_bot = self.pw.add("door", self.gap_bot)
        self.pw.objects[d_bot]["state"]["locked"] = bool(
            self.task.get("lock_bot_door", False))
        self.pw.objects[d_bot]["state"]["open"] = not self.task.get(
            "close_bot_door", False)
        self._sync_door(d_top)
        self._sync_door(d_bot)
        self.doors = [d_top, d_bot]

        # switch + plate wired to the bottom door if requested
        if self.task.get("switch_opens_bot"):
            s = self.pw.add("switch", tuple(self.task.get("switch_pos", (60, 60))))
            self._door_links[s] = d_bot
        if self.task.get("plate_opens_top"):
            p = self.pw.add("plate", tuple(self.task.get("plate_pos", (400, 60))))
            self._door_links[p] = d_top

        # items
        key_pos = tuple(self.task.get("key_pos", (100, 60)))
        if self.task.get("with_key", True):
            self.pw.add("key", key_pos)
            if self.task.get("hide_key_under_box", False):
                self.pw.add("box", (key_pos[0] + 6, key_pos[1] + 6))
        self.pw.add("battery", tuple(self.task.get("battery_pos", (420, 240))))

        # humans
        for _ in range(self.task.get("n_humans", 2)):
            self.pw.add("human", tuple(self._spawn()))
        self._human_wp = {oid: self._spawn()
                          for oid, o in self.pw.objects.items()
                          if o["kind"] == "human"}

    def _spawn(self, room=None):
        for _ in range(200):
            x = self.layout_rng.uniform(40, W - 40)
            if room == "left":
                x = self.layout_rng.uniform(40, W / 2 - 40)
            elif room == "right":
                x = self.layout_rng.uniform(W / 2 + 40, W - 40)
            y = self.layout_rng.uniform(40, H - 40)
            if not self.pw.bodies_near((x, y), 30):
                return np.array([x, y])
        return np.array([W / 4, H / 2])

    # ============================ door plumbing ============================ #
    def _sync_door(self, oid):
        o = self.pw.objects[oid]
        o["shape"].sensor = bool(o["state"].get("open", False))

    def _open_door(self, oid, how: str):
        st = self.pw.objects[oid]["state"]
        if not st.get("open", False):
            st["open"] = True
            st["locked"] = False
            self._sync_door(oid)
            self.events.append(f"door_opened:{how}")

    # ================================ step ================================= #
    def step(self, action: int, light: bool = False):
        """light=True skips observation rendering (used by MCTS rollouts)."""
        assert 0 <= action < N_ACTIONS
        self.t += 1
        self.events = []
        interaction = None
        self.energy -= 0.05

        speed = 200.0 * (1.6 if self._in_speed_zone() else 1.0)
        heading = pymunk.Vec2d(math.sin(self.theta), math.cos(self.theta))

        name = ACTIONS[action]
        if name == "forward":
            self.robot.velocity = heading * speed
        elif name == "backward":
            self.robot.velocity = -heading * speed * 0.6
        elif name == "rotate_left":
            self.theta += math.pi / 10
        elif name == "rotate_right":
            self.theta -= math.pi / 10
        elif name in ("push", "pull", "grab"):
            interaction = self._interact(name, heading)
        elif name == "release":
            self._release()
        # wait / observe: no motor command
        self.theta = (self.theta + math.pi) % (2 * math.pi) - math.pi

        self._step_humans()
        self.pw.step()
        self.robot.velocity = self.robot.velocity * 0.55   # motor braking
        self._check_triggers()
        if interaction is not None:
            interaction = self._complete_interaction(interaction, action)

        obs = None if light else self._observe()
        reward, success = self._task_reward()
        terminated = success
        truncated = self.t >= self.max_steps or self.energy <= 0
        info = self._info(interaction)
        info.update(success=success)
        return obs, reward, terminated, truncated, info

    # --------------------------- interactions ------------------------------ #
    def _front_object(self):
        probe = self.robot.position + pymunk.Vec2d(
            math.sin(self.theta), math.cos(self.theta)) * (ROBOT_R + REACH * 0.5)
        for oid in self.pw.bodies_near(probe, REACH * 0.55):
            if self.pw.objects[oid]["kind"] not in ("human",):
                return oid
        return None

    def _object_state(self, oid):
        b = self.pw.objects[oid]["body"]
        return {"pos": tuple(b.position), "angle": float(b.angle),
                "vel": tuple(b.velocity),
                "robot_pos": tuple(self.robot.position),
                "robot_theta": float(self.theta)}

    def _interact(self, name, heading):
        oid = self._front_object()
        self.energy -= 0.2
        if oid is None:
            self.events.append(f"{name}_air")
            return None
        o = self.pw.objects[oid]
        before = self._object_state(oid)
        force = 0.0

        if name == "push":
            if o["kind"] == "door":
                st = o["state"]
                if st.get("open"):
                    pass
                elif st.get("locked") and "key" in self.inventory:
                    self.inventory.remove("key")
                    self._open_door(oid, "key")
                elif not st.get("locked"):
                    self._open_door(oid, "push")
                else:
                    self.events.append("door_locked")
            elif o["body"].body_type == pymunk.Body.DYNAMIC:
                force = 900.0
                o["body"].apply_impulse_at_world_point(
                    heading * force, tuple(self.robot.position))
        elif name == "pull":
            if o["body"].body_type == pymunk.Body.DYNAMIC:
                force = 650.0
                o["body"].apply_impulse_at_world_point(
                    -heading * force, tuple(self.robot.position))
        elif name == "grab":
            if o["spec"].grabbable:
                if o["spec"].special == "energy+40":
                    self.energy = min(100.0, self.energy + 40.0)
                    self.events.append("battery_consumed")
                else:
                    self.inventory.append(o["kind"])
                    self.events.append(f"grabbed:{o['kind']}")
                self.pw.remove(oid)
                return {"object_id": oid, "kind": o["kind"], "state_before": before,
                        "force": 0.0, "removed": True}
            elif o["spec"].draggable and self.grab_joint is None:
                j = pymunk.PivotJoint(self.robot, o["body"],
                                      tuple(self.robot.position +
                                            heading * (ROBOT_R + 6)))
                j.max_force = 5e4
                self.pw.space.add(j)
                self.grab_joint = (j, oid)
                self.events.append(f"holding:{o['kind']}")

        return {"object_id": oid, "kind": o["kind"], "state_before": before,
                "force": force, "removed": False}

    def _complete_interaction(self, inter, action):
        """Fill state_after once physics has resolved this step."""
        if inter.get("removed"):
            inter["state_after"] = None
            inter["displacement"] = 0.0
        else:
            after = self._object_state(inter["object_id"])
            inter["state_after"] = after
            inter["displacement"] = float(np.linalg.norm(
                np.array(after["pos"]) - np.array(inter["state_before"]["pos"])))
        inter["action"] = int(action)
        inter["t"] = self.t
        return inter

    def _release(self):
        if self.grab_joint is not None:
            j, oid = self.grab_joint
            self.pw.space.remove(j)
            self.grab_joint = None
            self.events.append("released")

    # ------------------------- world side-effects -------------------------- #
    def _check_triggers(self):
        for trig, door in self._door_links.items():
            if trig not in self.pw.objects:
                continue
            o = self.pw.objects[trig]
            tp = pymunk.Vec2d(*o["body"].position)
            if o["spec"].special == "switch":
                for oid2, o2 in self.pw.objects.items():
                    if o2["body"].body_type != pymunk.Body.DYNAMIC:
                        continue
                    if (tp - o2["body"].position).length < o["size"][0] + \
                            max(o2["size"]) / 2:
                        self._open_door(door, "switch")
                if (tp - self.robot.position).length < o["size"][0] + ROBOT_R:
                    self._open_door(door, "switch")
            elif o["spec"].special == "pressure_plate":
                for oid2, o2 in self.pw.objects.items():
                    if o2["body"].body_type != pymunk.Body.DYNAMIC:
                        continue
                    if o2["spec"].mass > 2.0 and \
                            (tp - o2["body"].position).length < max(o["size"]) / 2:
                        self._open_door(door, "plate")

    def _in_speed_zone(self):
        for oid, o in self.pw.objects.items():
            if o["spec"].special == "speed_zone":
                p = o["body"].position
                w, h = o["size"]
                r = self.robot.position
                if abs(r.x - p.x) < w / 2 and abs(r.y - p.y) < h / 2:
                    return True
        return False

    def _step_humans(self):
        for oid, o in self.pw.objects.items():
            if o["kind"] != "human":
                continue
            b = o["body"]
            wp = self._human_wp[oid]
            v = pymunk.Vec2d(*wp) - b.position
            if v.length < 20 or self.rng.random() < 0.005:
                self._human_wp[oid] = self._spawn()
            else:
                b.velocity = v.normalized() * 40.0

    # ------------------------------- task ---------------------------------- #
    def _task_reward(self):
        goal = self.task.get("goal", "explore")
        if goal.startswith("reach:"):
            kind = goal.split(":")[1]
            targets = [o["body"].position for o in self.pw.objects.values()
                       if o["kind"] == kind]
            if kind == "battery" and not targets:      # consumed = reached
                return 1.0, True
            if targets:
                d = min((self.robot.position - p).length for p in targets)
                if d < ROBOT_R + 18:
                    return 1.0, True
                prev = getattr(self, "_prev_goal_dist", d)
                self._prev_goal_dist = d
                return -0.002 + 0.004 * (prev - d), False   # progress shaping
            return -0.002, False
        if goal.startswith("room:"):                    # reach the other room
            side = goal.split(":")[1]
            x = self.robot.position.x
            ok = x > W / 2 + 30 if side == "right" else x < W / 2 - 30
            return (1.0, True) if ok else (-0.002, False)
        return 0.0, False                               # pure exploration

    # ============================ observations ============================= #
    def render_global(self) -> np.ndarray:
        img = Image.new("RGB", (W, H), FLOOR_COLOR)
        d = ImageDraw.Draw(img)

        def poly(o):
            b, (w, h) = o["body"], o["size"]
            cs, sn = math.cos(b.angle), math.sin(b.angle)
            pts = []
            for dx, dy in [(-w / 2, -h / 2), (w / 2, -h / 2),
                           (w / 2, h / 2), (-w / 2, h / 2)]:
                pts.append((b.position.x + dx * cs - dy * sn,
                            b.position.y + dx * sn + dy * cs))
            return pts

        order = ["ramp", "plate", "shelf", "table", "chair", "box", "pipe",
                 "switch", "key", "battery", "door", "human"]
        for kind in order:
            for oid, o in self.pw.objects.items():
                if o["kind"] != kind:
                    continue
                color = o["spec"].color
                if kind == "door":
                    if o["state"].get("open"):
                        d.polygon(poly(o), outline=DOOR_OPEN_COLOR, width=3)
                        continue
                    color = (150, 60, 130) if o["state"].get("locked") else color
                if o["spec"].shape == "circle":
                    p, r = o["body"].position, o["size"][0]
                    d.ellipse([p.x - r, p.y - r, p.x + r, p.y + r], fill=color)
                else:
                    d.polygon(poly(o), fill=color)
        for oid, o in self.pw.objects.items():
            if o["kind"] == "wall":
                a, b = o["state"]["a"], o["state"]["b"]
                d.line([a, b], fill=o["spec"].color, width=int(o["size"][0] * 2))

        p = self.robot.position
        d.ellipse([p.x - ROBOT_R, p.y - ROBOT_R, p.x + ROBOT_R, p.y + ROBOT_R],
                  fill=ROBOT_COLOR)
        tip = (p.x + math.sin(self.theta) * ROBOT_R * 0.9,
               p.y + math.cos(self.theta) * ROBOT_R * 0.9)
        d.ellipse([tip[0] - 3, tip[1] - 3, tip[0] + 3, tip[1] + 3],
                  fill=(250, 250, 250))
        return np.asarray(img, dtype=np.uint8)

    def _observe(self) -> dict:
        g = self.render_global()
        half = 84
        pad = int(half * 1.6)
        padded = np.pad(g, ((pad, pad), (pad, pad), (0, 0)), constant_values=20)
        cy = int(self.robot.position.y) + pad
        cx = int(self.robot.position.x) + pad
        big = int(half * 1.5)
        crop = padded[cy - big:cy + big, cx - big:cx + big]
        crop = _rotate_rgb(crop, -math.degrees(self.theta))
        c = crop.shape[0] // 2
        ego = crop[c - half:c + half, c - half:c + half]
        rgb = _resize_rgb(ego, self.obs_size)

        depth = np.empty(DEPTH_RAYS, dtype=np.float32)
        for i in range(DEPTH_RAYS):
            a = self.theta - DEPTH_FOV / 2 + DEPTH_FOV * i / (DEPTH_RAYS - 1)
            dist, _ = self.pw.raycast(tuple(self.robot.position +
                                            pymunk.Vec2d(math.sin(a), math.cos(a))
                                            * (ROBOT_R + 1)), a)
            depth[i] = dist / 300.0

        return {"rgb": rgb, "depth": depth,
                "robot_pose": np.array([self.robot.position.x / W,
                                        self.robot.position.y / H,
                                        self.theta], dtype=np.float32),
                "energy": float(self.energy), "time": self.t,
                "inventory": list(self.inventory)}

    def _info(self, interaction):
        return {"t": self.t, "events": list(self.events),
                "interaction": interaction,
                "doors_open": {d: self.pw.objects[d]["state"].get("open", False)
                               for d in getattr(self, "doors", [])}}

    # ------------------------ planning support ----------------------------- #
    def snapshot(self):
        return {"phys": self.pw.snapshot(),
                "robot": (tuple(self.robot.position), self.theta,
                          tuple(self.robot.velocity)),
                "energy": self.energy, "t": self.t,
                "inventory": list(self.inventory),
                "prev_goal_dist": getattr(self, "_prev_goal_dist", None)}

    def restore(self, snap):
        self.pw.restore(snap["phys"])
        (pos, th, vel) = snap["robot"]
        self.robot.position = pos
        self.robot.velocity = vel
        self.theta = th
        self.energy = snap["energy"]
        self.t = snap["t"]
        self.inventory = list(snap["inventory"])
        if snap.get("prev_goal_dist") is not None:
            self._prev_goal_dist = snap["prev_goal_dist"]
        for d in self.doors:
            self._sync_door(d)


# ------------------------ numpy-only image ops ----------------------------- #
def _resize_rgb(img, out):
    ys = (np.arange(out) * img.shape[0] / out).astype(int)
    xs = (np.arange(out) * img.shape[1] / out).astype(int)
    return img[ys][:, xs]


def _rotate_rgb(img, deg):
    th = np.deg2rad(deg)
    h, w = img.shape[:2]
    cy, cx = (h - 1) / 2, (w - 1) / 2
    ys, xs = np.mgrid[0:h, 0:w]
    ys = ys - cy
    xs = xs - cx
    sy = (np.cos(th) * ys - np.sin(th) * xs + cy).round().astype(int)
    sx = (np.sin(th) * ys + np.cos(th) * xs + cx).round().astype(int)
    ok = (sy >= 0) & (sy < h) & (sx >= 0) & (sx < w)
    out = np.full_like(img, 20)
    out[ok] = img[sy[ok], sx[ok]]
    return out
