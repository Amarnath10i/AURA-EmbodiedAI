"""
env/objects.py — the object catalogue.

Every object type has HIDDEN physics (mass, friction, size, special behaviour).
The robot NEVER reads these fields: they exist only inside the physics engine.
The whole research question is whether the agent can *discover* what objects
are for, purely from interaction experience.

Object ids are stable within an episode so experiences can be attributed to
specific objects ("chair_0 was pushed and moved 0.6m").
"""

from dataclasses import dataclass, field

# world units are pixels; robot radius is 14
@dataclass
class ObjectSpec:
    kind: str
    mass: float          # hidden
    friction: float      # hidden
    size: tuple          # hidden (w, h) or (radius,)
    shape: str           # "box" | "circle" | "segment"
    color: tuple
    grabbable: bool = False    # small enough to go into inventory
    draggable: bool = False    # can be grab-attached and dragged
    static: bool = False
    special: str = ""          # engine-side behaviour tag


CATALOGUE = {
    "wall":    ObjectSpec("wall",    0, 0.9, (0, 0), "segment", (60, 64, 72), static=True),
    "shelf":   ObjectSpec("shelf",   0, 0.9, (70, 18), "box", (146, 106, 66), static=True),
    "table":   ObjectSpec("table", 24.0, 0.85, (54, 34), "box", (120, 96, 70), draggable=True),
    "chair":   ObjectSpec("chair",  6.0, 0.55, (24, 24), "box", (176, 128, 84), draggable=True),
    "box":     ObjectSpec("box",    2.5, 0.40, (22, 22), "box", (203, 163, 92), draggable=True),
    "pipe":    ObjectSpec("pipe",   3.5, 0.30, (80, 8),  "box", (150, 155, 165), draggable=True),
    "key":     ObjectSpec("key",    0.2, 0.50, (7,),  "circle", (218, 180, 60), grabbable=True),
    "battery": ObjectSpec("battery",0.4, 0.50, (8,),  "circle", (80, 200, 120), grabbable=True,
                          special="energy+40"),
    "door":    ObjectSpec("door",   0, 0.9, (12, 66), "box", (178, 68, 60), static=True,
                          special="openable"),
    "human":   ObjectSpec("human",  0, 0.9, (13,), "circle", (66, 120, 200), static=False,
                          special="kinematic_walker"),
    "plate":   ObjectSpec("plate",  0, 0.9, (30, 30), "box", (120, 90, 160), static=True,
                          special="pressure_plate"),   # heavy object on top -> triggers
    "switch":  ObjectSpec("switch", 0, 0.9, (10,), "circle", (230, 80, 160), static=True,
                          special="switch"),           # any contact -> triggers
    "ramp":    ObjectSpec("ramp",   0, 0.05, (60, 60), "box", (190, 210, 190), static=True,
                          special="speed_zone"),       # low-friction floor: robot moves faster
}

ROBOT_COLOR = (40, 40, 46)
FLOOR_COLOR = (232, 229, 222)
DOOR_OPEN_COLOR = (120, 190, 120)
