"""
env/physics.py — thin pymunk wrapper.

Adds the two things planning needs on top of raw pymunk:
  * stable object registry (id -> body/shape/spec)
  * snapshot() / restore(): capture and reset full dynamic state, so MCTS can
    roll the world forward and rewind it (Generation 1 planning). Generation 2
    replaces these rollouts with world-model imagination.
"""

from __future__ import annotations
import math
import pymunk
from .objects import CATALOGUE


class PhysicsWorld:
    def __init__(self, damping: float = 0.6):
        self.space = pymunk.Space()
        self.space.gravity = (0, 0)          # top-down world
        self.space.damping = damping         # friction-with-floor stand-in
        self.objects = {}                    # id -> dict(kind, body, shape, spec, state)
        self._counter = {}

    # ------------------------------ creation ------------------------------ #
    def add(self, kind: str, pos, angle: float = 0.0, oid: str | None = None,
            size=None) -> str:
        spec = CATALOGUE[kind]
        if oid is None:
            n = self._counter.get(kind, 0)
            self._counter[kind] = n + 1
            oid = f"{kind}_{n}"
        size = size or spec.size

        if spec.static or spec.special == "kinematic_walker":
            body = pymunk.Body(body_type=pymunk.Body.KINEMATIC
                               if spec.special == "kinematic_walker"
                               else pymunk.Body.STATIC)
        else:
            if spec.shape == "circle":
                moment = pymunk.moment_for_circle(spec.mass, 0, size[0])
            else:
                moment = pymunk.moment_for_box(spec.mass, size)
            body = pymunk.Body(spec.mass, moment)
        body.position = pos
        body.angle = angle

        if spec.shape == "circle":
            shape = pymunk.Circle(body, size[0])
        else:
            shape = pymunk.Poly.create_box(body, size)
        shape.friction = spec.friction
        # sensors: zones that detect but don't collide
        if spec.special in ("pressure_plate", "switch", "speed_zone"):
            shape.sensor = True

        self.space.add(body, shape)
        self.objects[oid] = {"kind": kind, "body": body, "shape": shape,
                             "spec": spec, "size": size,
                             "state": {}}       # per-object mutable flags (door open etc.)
        return oid

    def add_wall(self, a, b, thickness=4.0) -> str:
        n = self._counter.get("wall", 0)
        self._counter["wall"] = n + 1
        oid = f"wall_{n}"
        body = pymunk.Body(body_type=pymunk.Body.STATIC)
        shape = pymunk.Segment(body, a, b, thickness)
        shape.friction = 0.9
        self.space.add(body, shape)
        self.objects[oid] = {"kind": "wall", "body": body, "shape": shape,
                             "spec": CATALOGUE["wall"], "size": (thickness,),
                             "state": {"a": a, "b": b}}
        return oid

    def remove(self, oid: str):
        o = self.objects.pop(oid)
        self.space.remove(o["body"], o["shape"])

    # ------------------------------ stepping ------------------------------ #
    def step(self, dt: float = 1 / 30, substeps: int = 2):
        for _ in range(substeps):
            self.space.step(dt / substeps)

    # --------------------------- spatial queries --------------------------- #
    def bodies_near(self, point, radius: float):
        hits = []
        for oid, o in self.objects.items():
            if o["kind"] == "wall":
                continue
            d = (pymunk.Vec2d(*point) - o["body"].position).length
            reach = radius + (o["size"][0] if o["spec"].shape == "circle"
                              else max(o["size"]) / 2)
            if d < reach:
                hits.append((d, oid))
        return [oid for _, oid in sorted(hits)]

    def raycast(self, origin, angle, max_dist=300.0):
        end = (origin[0] + max_dist * math.sin(angle),
               origin[1] + max_dist * math.cos(angle))
        info = self.space.segment_query_first(origin, end, 1.0,
                                              pymunk.ShapeFilter())
        if info is None:
            return max_dist, None
        oid = next((k for k, o in self.objects.items() if o["shape"] is info.shape), None)
        return (pymunk.Vec2d(*origin) - info.point).length, oid

    # -------------------------- snapshot / restore ------------------------- #
    def snapshot(self) -> dict:
        st = {}
        for oid, o in self.objects.items():
            b = o["body"]
            st[oid] = (tuple(b.position), b.angle, tuple(b.velocity),
                       b.angular_velocity, dict(o["state"]))
        return st

    def restore(self, snap: dict):
        for oid, (pos, ang, vel, avel, state) in snap.items():
            if oid not in self.objects:      # object was removed after snapshot
                continue
            b = self.objects[oid]["body"]
            b.position = pos
            b.angle = ang
            if b.body_type == pymunk.Body.DYNAMIC or b.body_type == pymunk.Body.KINEMATIC:
                b.velocity = vel
                b.angular_velocity = avel
            self.objects[oid]["state"] = dict(state)
        for o in self.objects.values():
            self.space.reindex_shapes_for_body(o["body"])
