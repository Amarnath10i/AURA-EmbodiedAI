"""
function_learning/function_encoder.py — Generation 3: the research contribution.

Goal: map an object's ENTIRE interaction history to a *function embedding* —
a learned vector describing what the object can do for the agent. No labels
like "movable=True" exist anywhere; the geometry of the embedding space must
emerge from experience alone.

    experiences_with_object_X  ->  TransformerSet  ->  f_X  in R^32

Intended training signals (research menu — this is where the paper lives):
  1. Predictive:  f_X should improve world-model prediction for interactions
     with X (function = "how X responds to me").
  2. Contrastive: histories of the SAME object across episodes -> near;
     different objects -> far (InfoNCE). Objects with similar physics should
     cluster WITHOUT ever being told their category.
  3. Goal-conditioned: planner scores strategies in function space
     ("I need something push-standable near the shelf").

Implemented here: the encoder architecture + the contrastive objective (2),
which is the first testable claim: *does an unlabelled embedding space
recover object categories and affordance structure?* Evaluate by clustering
f_X vectors and comparing to ground-truth kinds the sim knows but never
revealed.
"""

from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F

from memory.experience import experience_vector  # 16-d interaction features

FUNCTION_DIM = 32


class FunctionEncoder(nn.Module):
    """Set transformer over an object's interaction records -> function vector."""

    def __init__(self, exp_dim: int = 16, d_model: int = 64,
                 n_layers: int = 2, n_heads: int = 4,
                 out_dim: int = FUNCTION_DIM):
        super().__init__()
        self.inp = nn.Linear(exp_dim, d_model)
        self.cls = nn.Parameter(torch.zeros(1, 1, d_model))
        layer = nn.TransformerEncoderLayer(d_model, n_heads,
                                           dim_feedforward=4 * d_model,
                                           batch_first=True, norm_first=True)
        self.tf = nn.TransformerEncoder(layer, n_layers)
        self.out = nn.Linear(d_model, out_dim)

    def forward(self, exps: torch.Tensor, mask: torch.Tensor | None = None):
        """exps: (B, N, 16) padded interaction features; mask: (B, N) True=pad."""
        B = exps.shape[0]
        h = torch.cat([self.cls.expand(B, 1, -1), self.inp(exps)], dim=1)
        if mask is not None:
            mask = torch.cat([torch.zeros(B, 1, dtype=torch.bool,
                                          device=mask.device), mask], dim=1)
        h = self.tf(h, src_key_padding_mask=mask)
        return F.normalize(self.out(h[:, 0]), dim=-1)


def info_nce(anchor: torch.Tensor, positive: torch.Tensor,
             temperature: float = 0.1) -> torch.Tensor:
    """Anchor/positive = embeddings of two disjoint experience subsets of the
    SAME object; every other object in the batch is a negative."""
    logits = anchor @ positive.T / temperature
    labels = torch.arange(len(anchor), device=anchor.device)
    return F.cross_entropy(logits, labels)


def experiences_to_tensor(records: list[dict], max_n: int = 32):
    """List of experience dicts (one object) -> (max_n, 16) + pad mask."""
    vecs = [experience_vector(r) for r in records[:max_n]]
    n = len(vecs)
    out = torch.zeros(max_n, 16)
    if n:
        out[:n] = torch.tensor(vecs)
    mask = torch.ones(max_n, dtype=torch.bool)
    mask[:n] = False
    return out, mask


# ---------------------------------------------------------------------------
# Predictive function objective (the principled Gen-3 contribution)
#
# Why not plain InfoNCE? Instance discrimination pushes EVERY object apart —
# including chair_0 from chair_1. It therefore learns object *identity*, which
# is the opposite of what "function" means. Measured result: 0% kind agreement.
#
# A function is better defined as *how an object responds to actions*. So we
# force the embedding through a predictive bottleneck:
#
#       f_X = Encoder(history of X)                      (32-d)
#       outcome_hat = Head(f_X, action a)  ->  MSE vs true outcome
#
# f_X only needs to carry the object's action-response profile, so two objects
# with the same hidden physics converge to the same embedding WITHOUT ever
# being told they share a category.
# ---------------------------------------------------------------------------

class FunctionPredictor(nn.Module):
    """f_X + action -> predicted interaction outcome (displacement, moved?)."""

    def __init__(self, n_actions: int = 10, func_dim: int = FUNCTION_DIM,
                 hidden: int = 64):
        super().__init__()
        self.a_emb = nn.Embedding(n_actions, 16)
        self.net = nn.Sequential(
            nn.Linear(func_dim + 16, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, 2),          # [displacement, moved_logit]
        )

    def forward(self, f: torch.Tensor, a: torch.Tensor) -> torch.Tensor:
        return self.net(torch.cat([f, self.a_emb(a)], dim=-1))


def outcome_targets(records: list[dict]) -> torch.Tensor:
    """True outcome per record: [normalised displacement, moved flag]."""
    out = []
    for r in records:
        d = float(r.get("displacement", 0.0)) / 100.0
        out.append([d, 1.0 if d > 0.02 else 0.0])
    return torch.tensor(out, dtype=torch.float32)
