"""
memory/experience.py — the Experience Memory (first novel component).

Every *interaction* with an object becomes one structured record:

    Experience = { object_id, kind, state_before, action, force,
                   state_after, displacement, reward, prediction_error, t }

Storage:
  * SQLite  — durable, queryable records ("all pushes on chairs", "all
              experiences with prediction_error > 0.5")
  * VectorIndex — similarity search over experience feature vectors, used for
              failure clustering and (Gen 3) function learning. Numpy-backed
              with the same add/search interface as FAISS IndexFlatL2, so
              swapping FAISS in later is a two-line change.
"""

from __future__ import annotations
import json
import sqlite3
import numpy as np

try:                                     # optional FAISS acceleration
    import faiss                         # type: ignore
    _HAS_FAISS = True
except ImportError:
    _HAS_FAISS = False


class VectorIndex:
    def __init__(self, dim: int):
        self.dim = dim
        if _HAS_FAISS:
            self.index = faiss.IndexFlatL2(dim)
        else:
            self._vecs = np.empty((0, dim), dtype=np.float32)

    def add(self, vecs: np.ndarray):
        vecs = np.asarray(vecs, dtype=np.float32).reshape(-1, self.dim)
        if _HAS_FAISS:
            self.index.add(vecs)
        else:
            self._vecs = np.concatenate([self._vecs, vecs])

    def search(self, query: np.ndarray, k: int):
        q = np.asarray(query, dtype=np.float32).reshape(-1, self.dim)
        if _HAS_FAISS:
            return self.index.search(q, k)
        d = ((self._vecs[None] - q[:, None]) ** 2).sum(-1)   # (Q, N)
        idx = np.argsort(d, axis=1)[:, :k]
        return np.take_along_axis(d, idx, 1), idx

    def __len__(self):
        return self.index.ntotal if _HAS_FAISS else len(self._vecs)


def experience_vector(exp: dict) -> np.ndarray:
    """Fixed 16-d feature vector for an interaction (used for clustering)."""
    sb = exp.get("state_before") or {}
    sa = exp.get("state_after") or sb
    if isinstance(sb, str):
        import json as _j
        sb = _j.loads(sb) or {}
    if isinstance(sa, str):
        import json as _j
        sa = _j.loads(sa) or sb
    v = np.zeros(16, dtype=np.float32)
    v[exp["action"] % 10] = 1.0                       # one-hot action
    v[10] = exp.get("force", 0.0) / 1000.0
    v[11] = exp.get("displacement", 0.0) / 100.0
    v[12] = exp.get("reward", 0.0)
    v[13] = exp.get("prediction_error", 0.0)
    if sb and sa and sb.get("pos") and sa.get("pos"):
        v[14] = (sa["pos"][0] - sb["pos"][0]) / 100.0
        v[15] = (sa["pos"][1] - sb["pos"][1]) / 100.0
    return v


class ExperienceMemory:
    def __init__(self, path: str = "experience.db", dim: int = 16):
        self.conn = sqlite3.connect(path)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS experience (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                episode INTEGER, t INTEGER,
                object_id TEXT, kind TEXT, action INTEGER,
                force REAL, displacement REAL, reward REAL,
                prediction_error REAL,
                state_before TEXT, state_after TEXT)""")
        self.index = VectorIndex(dim)
        self._ids: list[int] = []          # row ids aligned with index order

    def add(self, exp: dict, episode: int = 0):
        cur = self.conn.execute(
            """INSERT INTO experience (episode,t,object_id,kind,action,force,
               displacement,reward,prediction_error,state_before,state_after)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (episode, exp.get("t", 0), exp["object_id"], exp["kind"],
             exp["action"], exp.get("force", 0.0), exp.get("displacement", 0.0),
             exp.get("reward", 0.0), exp.get("prediction_error", 0.0),
             json.dumps(exp.get("state_before")), json.dumps(exp.get("state_after"))))
        self.conn.commit()
        self.index.add(experience_vector(exp))
        self._ids.append(cur.lastrowid)
        return cur.lastrowid

    def query(self, where: str = "1=1", params=()):
        cur = self.conn.execute(
            f"SELECT kind, action, force, displacement, reward, "
            f"prediction_error, object_id, t, state_before, state_after "
            f"FROM experience WHERE {where}", params)
        cols = ["kind", "action", "force", "displacement", "reward",
                "prediction_error", "object_id", "t", "state_before",
                "state_after"]
        return [dict(zip(cols, r)) for r in cur.fetchall()]

    def similar(self, exp: dict, k: int = 5):
        d, idx = self.index.search(experience_vector(exp), k)
        rows = []
        for i in idx[0]:
            if 0 <= i < len(self._ids):
                r = self.query("id=?", (self._ids[int(i)],))
                rows += r
        return rows

    def stats_by_kind(self):
        cur = self.conn.execute(
            """SELECT kind, action, COUNT(*), AVG(displacement), AVG(force)
               FROM experience GROUP BY kind, action""")
        return cur.fetchall()

    def __len__(self):
        cur = self.conn.execute("SELECT COUNT(*) FROM experience")
        return cur.fetchone()[0]
