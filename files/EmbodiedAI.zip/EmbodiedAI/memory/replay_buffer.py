"""memory/replay_buffer.py — transition storage for world-model training.

Stores full observation dicts as parallel arrays; serves random (sequence)
minibatches. Saved as compressed .npz shards.
"""

from __future__ import annotations
import os
import numpy as np


class ReplayBuffer:
    def __init__(self):
        self.rgb, self.depth, self.pose = [], [], []
        self.action, self.energy = [], []
        self.episode, self.t = [], []

    def add(self, obs: dict, action: int, episode: int):
        self.rgb.append(obs["rgb"])
        self.depth.append(obs["depth"])
        self.pose.append(obs["robot_pose"])
        self.action.append(action)
        self.energy.append(obs["energy"])
        self.episode.append(episode)
        self.t.append(obs["time"])

    def save(self, path: str):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        np.savez_compressed(
            path,
            rgb=np.asarray(self.rgb, dtype=np.uint8),
            depth=np.asarray(self.depth, dtype=np.float32),
            pose=np.asarray(self.pose, dtype=np.float32),
            action=np.asarray(self.action, dtype=np.int8),
            energy=np.asarray(self.energy, dtype=np.float32),
            episode=np.asarray(self.episode, dtype=np.int32),
            t=np.asarray(self.t, dtype=np.int32))

    @staticmethod
    def load(path: str) -> dict:
        with np.load(path) as z:
            return {k: z[k] for k in z.files}

    @staticmethod
    def sample_pairs(data: dict, batch: int, rng) -> tuple:
        """Random (obs_t, action_t, obs_t+1) pairs within episodes."""
        ep = data["episode"]
        valid = np.where(ep[:-1] == ep[1:])[0]
        i = rng.choice(valid, size=batch)
        return data["rgb"][i], data["action"][i], data["rgb"][i + 1]

    def __len__(self):
        return len(self.action)
