"""
main.py — EmbodiedAI entry point.

Commands:
  explore   Generation 1: curious exploration; fills replay buffer +
            experience DB with object interactions.
  train     Generation 2: train CNN + transformer world model on replay data.
  functions Generation 3: train the object function encoder on experience DB.
  plan      MCTS planning demo on a benchmark level (simulator rollouts).
  demo      Render an exploration episode to GIF.

Example first run:
  python main.py explore --episodes 6
  python main.py train --steps 300
  python main.py plan --level 1
"""

from __future__ import annotations
import argparse
import numpy as np

from env.warehouse import Warehouse, ACTIONS
from planner.planner import CuriousExplorer, MCTSPolicy
from memory.replay_buffer import ReplayBuffer
from memory.experience import ExperienceMemory


def cmd_explore(args):
    buf = ReplayBuffer()
    mem = ExperienceMemory(args.db)
    totals = {"interactions": 0, "events": 0}
    for ep in range(args.episodes):
        env = Warehouse(seed=args.seed * 1000 + ep, max_steps=args.max_steps)
        policy = CuriousExplorer(seed=ep)
        obs, info = env.reset()
        while True:
            a = policy.act(obs, info)
            buf.add(obs, a, ep)
            obs, r, term, trunc, info = env.step(a)
            inter = info.get("interaction")
            if inter:
                inter["reward"] = r
                inter["prediction_error"] = 0.0     # filled once Gen 2 exists
                mem.add(inter, episode=ep)
                totals["interactions"] += 1
            totals["events"] += len(info["events"])
            if term or trunc:
                break
        print(f"episode {ep}: {env.t} steps, energy {env.energy:.0f}, "
              f"memory {len(mem)} experiences")
    buf.save(args.out)
    print(f"replay: {len(buf)} transitions -> {args.out}")
    print(f"experience DB: {len(mem)} interaction records -> {args.db}")
    print("interactions by (kind, action):")
    for kind, action, n, avg_disp, avg_force in mem.stats_by_kind():
        print(f"  {kind:8s} {ACTIONS[action]:12s} n={n:4d} "
              f"avg_displacement={avg_disp:6.1f}px")


def cmd_train(args):
    from training.train_world_model import train
    train(args.data, steps=args.steps, batch=args.batch, ctx=args.ctx,
          seed=args.seed)


def cmd_functions(args):
    from training.train_function_model import train
    train(args.db, steps=args.steps)


def cmd_plan(args):
    from evaluation.benchmark import run_level
    res = run_level(args.level, MCTSPolicy(seed=args.seed, n_sim=args.n_sim),
                    seed=args.seed, max_steps=args.max_steps, uses_env=True)
    print(res)


def cmd_demo(args):
    import imageio.v2 as imageio
    env = Warehouse(seed=args.seed, max_steps=args.max_steps)
    policy = CuriousExplorer(seed=args.seed)
    obs, info = env.reset()
    frames = []
    while True:
        a = policy.act(obs, info)
        obs, r, term, trunc, info = env.step(a)
        if env.t % 2 == 0:
            frames.append(env.render_global())
        if term or trunc:
            break
    imageio.mimsave(args.gif, frames, fps=15, loop=0)
    print(f"saved {args.gif} ({len(frames)} frames)")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)

    e = sub.add_parser("explore")
    e.add_argument("--episodes", type=int, default=6)
    e.add_argument("--max-steps", type=int, default=400)
    e.add_argument("--seed", type=int, default=0)
    e.add_argument("--out", default="data/replay.npz")
    e.add_argument("--db", default="experience.db")

    t = sub.add_parser("train")
    t.add_argument("--data", default="data/replay.npz")
    t.add_argument("--steps", type=int, default=300)
    t.add_argument("--batch", type=int, default=32)
    t.add_argument("--ctx", type=int, default=4)
    t.add_argument("--seed", type=int, default=0)

    f = sub.add_parser("functions")
    f.add_argument("--db", default="experience.db")
    f.add_argument("--steps", type=int, default=300)

    pl = sub.add_parser("plan")
    pl.add_argument("--level", type=int, default=1)
    pl.add_argument("--n-sim", type=int, default=60)
    pl.add_argument("--seed", type=int, default=0)
    pl.add_argument("--max-steps", type=int, default=600)

    d = sub.add_parser("demo")
    d.add_argument("--seed", type=int, default=0)
    d.add_argument("--max-steps", type=int, default=300)
    d.add_argument("--gif", default="exploration_demo.gif")

    args = p.parse_args()
    {"explore": cmd_explore, "train": cmd_train, "functions": cmd_functions,
     "plan": cmd_plan, "demo": cmd_demo}[args.cmd](args)
