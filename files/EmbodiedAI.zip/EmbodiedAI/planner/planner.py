"""
planner/planner.py — policies for each Generation.

CuriousExplorer (Gen 1): intrinsic-drive exploration. No task reward needed:
  * seeks motion (forward bias), avoids repeating collisions
  * interaction drive: when near objects, tries push/pull/grab far more often
  * novelty bonus via visit counts on a coarse position grid
This is what fills the Experience Memory with diverse interactions.

MCTSPolicy (Gen 1 planning): task-directed search using the simulator.
Gen 2 replaces the simulate function with world-model imagination.
"""

from __future__ import annotations
import numpy as np
from .mcts import MCTSPlanner


class CuriousExplorer:
    def __init__(self, seed: int = 0, grid: int = 12):
        self.rng = np.random.default_rng(seed)
        self.visits = np.zeros((grid, grid))
        self.grid = grid
        self.last_collision = False
        self.air_streak = 0

    def act(self, obs: dict, info: dict) -> int:
        # update novelty map
        x, y, _ = obs["robot_pose"]
        gx = min(self.grid - 1, int(x * self.grid))
        gy = min(self.grid - 1, int(y * self.grid))
        self.visits[gy, gx] += 1

        depth = obs["depth"]
        n = len(depth)
        front = float(depth[n // 2 - 4: n // 2 + 4].mean())

        # if last interaction hit air, stop grinding this spot
        if any(e.endswith("_air") for e in info.get("events", [])):
            self.air_streak += 1
        else:
            self.air_streak = 0
        if self.air_streak >= 2:
            self.air_streak = 0
            return int(self.rng.choice([2, 3]))

        # something within reach ahead -> strong interaction drive
        if front < 0.30 and self.rng.random() < 0.6:
            return int(self.rng.choice([4, 4, 5, 6, 6, 7]))  # push/pull/grab/release

        # depth-guided seeking toward NARROW dips = free-standing objects
        # (walls produce wide flat minima; skip those)
        i_min = int(np.argmin(depth))
        narrow = (depth < depth[i_min] + 0.06).sum() <= 10
        if narrow and depth[i_min] < 0.55 and self.rng.random() < 0.6:
            if i_min < n // 2 - 3:
                return 3          # ray at negative offset -> theta -= step
            if i_min > n // 2 + 3:
                return 2          # ray at positive offset -> theta += step
            return 0              # roughly ahead -> approach
        # blocked -> turn (away from over-visited side)
        if front < 0.16:
            return int(self.rng.choice([2, 3]))
        # novelty steering: occasionally rotate toward less-visited half
        if self.rng.random() < 0.15:
            left = self.visits[:, : self.grid // 2].sum()
            right = self.visits[:, self.grid // 2:].sum()
            return 2 if left < right else 3
        return int(self.rng.choice([0, 0, 0, 0, 1, 2, 3, 8],
                                   p=[0.55, 0.1, 0.1, 0.05, 0.05, 0.06, 0.06, 0.03]))


class MCTSPolicy:
    def __init__(self, seed: int = 0, n_sim: int = 40, depth: int = 5):
        self.mcts = MCTSPlanner(n_sim=n_sim, depth=depth, seed=seed)
        self._queue: list[int] = []

    def act(self, env) -> int:
        from .mcts import REPEAT
        if not self._queue:
            a = self.mcts.plan(env)
            self._queue = [a] * REPEAT
        return self._queue.pop()
