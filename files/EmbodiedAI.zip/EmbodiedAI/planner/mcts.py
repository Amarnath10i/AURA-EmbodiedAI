"""
planner/mcts.py — Monte-Carlo Tree Search over PRIMITIVE actions.

Generation 1: rollouts use the simulator's snapshot/restore (ground-truth
dynamics). Generation 2 swaps the rollout source for world-model imagination —
the search code does not change, only where futures come from.

Key design points:
  * Macro-actions: each tree edge repeats a primitive REPEAT times, otherwise
    the lookahead horizon in wall-clock terms is far too short to cross a room.
  * Full expansion: every untried action at a node is tried once before the
    search descends. (A previous version expanded one child per node, which
    degenerated the tree into a chain and never compared first actions.)
  * Movement-biased rollout policy: uniform-random rollouts mostly spin in
    place and give the value estimate no signal.
"""

from __future__ import annotations
import math
import numpy as np

REPEAT = 6          # primitive repeats per tree edge (macro-action length)
C_UCT = 1.0
GAMMA = 0.97

# rollout policy: favour locomotion, keep some interaction probability
ROLLOUT_P = np.array([0.42, 0.04, 0.16, 0.16, 0.08, 0.04, 0.06, 0.02, 0.01, 0.01])


class Node:
    __slots__ = ("parent", "action", "children", "untried", "n", "w", "snap")

    def __init__(self, actions, parent=None, action=None, snap=None):
        self.parent, self.action, self.snap = parent, action, snap
        self.children: dict[int, "Node"] = {}
        self.untried = list(actions)
        self.n = 0
        self.w = 0.0

    @property
    def q(self):
        return self.w / self.n if self.n else 0.0

    def best_child(self, c_uct=C_UCT):
        logN = math.log(self.n + 1)
        return max(self.children.values(),
                   key=lambda ch: ch.q + c_uct * math.sqrt(logN / (ch.n + 1e-9)))


class MCTSPlanner:
    def __init__(self, actions=range(10), n_sim: int = 80, depth: int = 8,
                 rollout_depth: int = 6, seed: int = 0):
        self.actions = list(actions)
        self.n_sim = n_sim
        self.depth = depth
        self.rollout_depth = rollout_depth
        self.rng = np.random.default_rng(seed)

    # ------------------------------ search -------------------------------- #
    def plan(self, env) -> int:
        root_snap = env.snapshot()
        root = Node(self.actions, snap=root_snap)

        for _ in range(self.n_sim):
            env.restore(root_snap)
            node, depth, value, done = root, 0, 0.0, False
            discount = 1.0

            # --- selection: descend fully-expanded nodes ---
            while not node.untried and node.children and depth < self.depth:
                node = node.best_child()
                r, done = self._advance(env, node.action)
                value += discount * r
                discount *= GAMMA
                depth += 1
                if done:
                    break

            # --- expansion: try one untried action here ---
            if not done and node.untried and depth < self.depth:
                a = int(self.rng.choice(node.untried))
                node.untried.remove(a)
                r, done = self._advance(env, a)
                value += discount * r
                discount *= GAMMA
                child = Node(self.actions, parent=node, action=a)
                node.children[a] = child
                node = child

            # --- simulation: movement-biased rollout ---
            if not done:
                value += discount * self._rollout(env)

            # --- backprop ---
            while node is not None:
                node.n += 1
                node.w += value
                node = node.parent

        env.restore(root_snap)
        if not root.children:
            return int(self.rng.choice(self.actions))
        # most-visited child, ties broken by value
        best = max(root.children.values(), key=lambda ch: (ch.n, ch.q))
        return best.action

    # ---------------------------- primitives ------------------------------- #
    def _advance(self, env, action) -> tuple[float, bool]:
        """Execute one macro-action. Returns (summed reward, episode_over)."""
        total = 0.0
        for _ in range(REPEAT):
            _, r, term, trunc, _ = env.step(action, light=True)
            total += r
            if term:
                return total + 1.0, True      # reaching the goal is worth a lot
            if trunc:
                return total, True
        return total, False

    def _rollout(self, env) -> float:
        total, discount = 0.0, 1.0
        for _ in range(self.rollout_depth):
            a = int(self.rng.choice(len(ROLLOUT_P), p=ROLLOUT_P))
            r, done = self._advance(env, a)
            total += discount * r
            discount *= GAMMA
            if done:
                break
        return total
