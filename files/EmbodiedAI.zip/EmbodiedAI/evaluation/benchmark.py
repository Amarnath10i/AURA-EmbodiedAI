"""
evaluation/benchmark.py — the five benchmark levels from the spec.

L1  Reach the battery (open world, both doors open)
L2  Door locked -> find the key, use it (nothing says keys open doors!)
L3  Key hidden under a box -> push box, grab key, open door
L4  Object as tool -> a switch (reachable by pushed objects) opens the door
L5  Never-seen warehouse layout (new layout_seed) -> generalization

Each level returns a task dict for Warehouse(...) plus a success criterion
already wired into the env's reward. run_level() executes a policy and
reports success / steps / interactions used.
"""

from __future__ import annotations
import numpy as np
from env.warehouse import Warehouse

LEVELS = {
    1: dict(goal="reach:battery", close_top_door=False, close_bot_door=False,
            with_key=False, battery_pos=(420, 240)),
    2: dict(goal="reach:battery", close_top_door=True, lock_top_door=True,
            close_bot_door=True, lock_bot_door=True,
            with_key=True, key_pos=(100, 60), battery_pos=(420, 240)),
    3: dict(goal="reach:battery", close_top_door=True, lock_top_door=True,
            close_bot_door=True, lock_bot_door=True,
            with_key=True, key_pos=(100, 60), hide_key_under_box=True,
            battery_pos=(420, 240)),
    4: dict(goal="reach:battery", close_top_door=True, lock_top_door=True,
            close_bot_door=True, lock_bot_door=True,    # switch is the ONLY way
            with_key=False, switch_opens_bot=True, switch_pos=(165, 440),
            battery_pos=(420, 240)),
    5: dict(goal="reach:battery", close_top_door=True, close_bot_door=False,
            with_key=True, battery_pos=(420, 240)),      # + fresh layout_seed
}


def make_env(level: int, seed: int = 0, max_steps: int = 800) -> Warehouse:
    task = dict(LEVELS[level])
    layout_seed = seed + 999 if level == 5 else None     # unseen warehouse
    return Warehouse(seed=seed, task=task, max_steps=max_steps,
                     layout_seed=layout_seed)


def run_level(level: int, policy, seed: int = 0, max_steps: int = 800,
              uses_env: bool = False) -> dict:
    env = make_env(level, seed, max_steps)
    obs, info = env.reset()
    interactions = 0
    while True:
        a = policy.act(env) if uses_env else policy.act(obs, info)
        obs, r, term, trunc, info = env.step(a)
        if info.get("interaction"):
            interactions += 1
        if term or trunc:
            return {"level": level, "success": bool(info.get("success")),
                    "steps": env.t, "interactions": interactions,
                    "energy_left": round(env.energy, 1),
                    "events_doors": info["doors_open"]}


def run_suite(policy_factory, seeds=(0, 1, 2), uses_env: bool = False):
    results = []
    for level in LEVELS:
        for s in seeds:
            results.append(run_level(level, policy_factory(s), seed=s,
                                     uses_env=uses_env))
    by_level = {}
    for r in results:
        by_level.setdefault(r["level"], []).append(r["success"])
    print("success rate by level:",
          {L: f"{100 * np.mean(v):.0f}%" for L, v in by_level.items()})
    return results
