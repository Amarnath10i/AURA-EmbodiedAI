"""evaluation/compare_objectives.py — Gen-3 ablation: which objective yields
function structure? Reports same-kind nearest-neighbour agreement, normalised
by the achievable ceiling, across seeds."""
from __future__ import annotations
import json
import numpy as np
import torch

from training.train_function_predictive import (
    load_histories, evaluate, train as train_pred)
from function_learning.function_encoder import FunctionEncoder
from training.train_function_model import train as train_contrastive


def random_init_baseline(hist, oids, seed):
    torch.manual_seed(seed)
    return evaluate(FunctionEncoder(), hist, oids)


def main(db="experience.db", seeds=(0, 1, 2), steps=400):
    hist = load_histories(db)
    oids = sorted(hist)
    out = {}

    rows = [random_init_baseline(hist, oids, s) for s in seeds]
    out["random_init"] = [r[0] for r in rows]
    ceiling, n = rows[0][1], rows[0][2]

    pred = []
    for s in seeds:
        c, ceil, n = train_pred(db, steps=steps, seed=s)
        pred.append(c)
    out["predictive"] = pred

    contra = []
    for s in seeds:
        m = train_contrastive(db, steps=steps, seed=s)
        contra.append(evaluate(m, hist, oids)[0] if m is not None else 0)
    out["contrastive"] = contra

    print("\n=== Gen-3 objective ablation ===")
    print(f"objects={n}  achievable ceiling={ceiling}")
    for k, v in out.items():
        m = np.mean(v)
        print(f"  {k:12s} {m:.1f}/{n}  ({100*m/ceiling:.0f}% of ceiling)  raw={v}")
    json.dump({"ceiling": ceiling, "n": n, "results": out},
              open("function_ablation.json", "w"), indent=2)
    return out


if __name__ == "__main__":
    main()
