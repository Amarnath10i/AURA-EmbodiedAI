"""evaluation/run_benchmark.py — compare policies across all levels and seeds."""
from __future__ import annotations
import json, time
import numpy as np
from evaluation.benchmark import run_level
from evaluation.oracle import OraclePolicy
from planner.planner import MCTSPolicy, CuriousExplorer


class RandomPolicy:
    def __init__(self, seed=0): self.rng = np.random.default_rng(seed)
    def act(self, obs, info): return int(self.rng.integers(10))


def main(seeds=(0, 1, 2), max_steps=700, n_sim=60, out="results.json"):
    policies = {
        "random":  (lambda s: RandomPolicy(s), False),
        "curious": (lambda s: CuriousExplorer(s), False),
        "mcts":    (lambda s: MCTSPolicy(seed=s, n_sim=n_sim), True),
        "oracle":  (lambda s: OraclePolicy(s), True),
    }
    results = {}
    for name, (factory, uses_env) in policies.items():
        results[name] = {}
        for lvl in (1, 2, 3, 4, 5):
            succ, steps = [], []
            for s in seeds:
                t0 = time.time()
                r = run_level(lvl, factory(s), seed=s, max_steps=max_steps,
                              uses_env=uses_env)
                succ.append(r["success"]); steps.append(r["steps"])
            results[name][lvl] = {"success_rate": float(np.mean(succ)),
                                  "mean_steps": float(np.mean(steps))}
            print(f"{name:8s} L{lvl}: {100*np.mean(succ):3.0f}%  "
                  f"mean_steps={np.mean(steps):.0f}")
    with open(out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nsaved {out}")
    return results


if __name__ == "__main__":
    main()
