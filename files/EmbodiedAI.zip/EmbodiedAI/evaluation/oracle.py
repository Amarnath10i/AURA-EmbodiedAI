"""
evaluation/oracle.py — scripted upper-bound policy (VALIDATION ONLY).

Uses ground-truth object positions the agent never sees. Its only purpose is to
prove each benchmark level is solvable, so that a learning agent's failure is a
genuine planning/representation limitation rather than a broken environment.
Never use the oracle as a baseline for the paper's main results.
"""
from __future__ import annotations
import math
import numpy as np


class OraclePolicy:
    """Waypoint follower: key -> nearest door -> battery."""

    def __init__(self, seed: int = 0):
        self.rng = np.random.default_rng(seed)
        self.stage = 0
        self.push_cool = 0

    def _find(self, env, kind):
        return [(oid, o["body"].position) for oid, o in env.pw.objects.items()
                if o["kind"] == kind]

    def act(self, env) -> int:
        r = env.robot.position
        keys = self._find(env, "key")
        batts = self._find(env, "battery")
        doors = [(oid, o["body"].position) for oid, o in env.pw.objects.items()
                 if o["kind"] == "door"]
        open_doors = [d for d in doors
                      if env.pw.objects[d[0]]["state"].get("open")]

        in_left = r.x < 240
        target, want_push = None, False

        switches = [(oid, o["body"].position) for oid, o in env.pw.objects.items()
                    if o["spec"].special == "switch"]
        locked_all = all(env.pw.objects[d[0]]["state"].get("locked")
                         for d in doors) if doors else False

        if switches and in_left and not open_doors and locked_all and not keys:
            target = switches[0][1]                   # switch is the only way
        elif keys and "key" not in env.inventory and in_left:
            target = keys[0][1]                       # fetch the key first
        elif in_left and not open_doors:
            target = min(doors, key=lambda d: (d[1] - r).length)[1]
            want_push = True                          # open a door
        elif in_left:
            target = min(open_doors, key=lambda d: (d[1] - r).length)[1]
        elif batts:
            target = batts[0][1]
        else:
            return 8

        v = target - r
        dist = v.length
        desired = math.atan2(v.x, v.y)                # env uses (sin, cos)
        err = (desired - env.theta + math.pi) % (2 * math.pi) - math.pi

        if dist < 34:
            if want_push and self.push_cool <= 0:
                self.push_cool = 3
                return 4                              # push (opens door / uses key)
            if keys and "key" not in env.inventory and dist < 26:
                return 6                              # grab
        self.push_cool = max(0, self.push_cool - 1)

        if err > 0.25:
            return 2
        if err < -0.25:
            return 3
        return 0
