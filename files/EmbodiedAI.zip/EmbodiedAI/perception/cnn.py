"""perception/cnn.py — small CNN encoder: 96x96x3 RGB -> 128-d latent.

Deliberately simple (Generation 1/2). The interface is one function:
    z = encoder(batch_of_images)   # (B, 128)
so DINOv3 can replace it later with zero changes elsewhere (only the latent
dimension constant moves to 768).
"""

import torch
import torch.nn as nn

LATENT_DIM = 128


class ConvEncoder(nn.Module):
    def __init__(self, latent_dim: int = LATENT_DIM):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(3, 32, 5, stride=2, padding=2), nn.ReLU(),   # 48
            nn.Conv2d(32, 64, 3, stride=2, padding=1), nn.ReLU(),  # 24
            nn.Conv2d(64, 128, 3, stride=2, padding=1), nn.ReLU(), # 12
            nn.Conv2d(128, 128, 3, stride=2, padding=1), nn.ReLU(),# 6
            nn.AdaptiveAvgPool2d(1), nn.Flatten(),
            nn.Linear(128, latent_dim),
            nn.LayerNorm(latent_dim),      # fixed latent scale -> stable training
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (B, 96, 96, 3) uint8 or (B, 3, 96, 96) float in [0,1]."""
        if x.dtype == torch.uint8:
            x = x.permute(0, 3, 1, 2).float() / 255.0
        return self.net(x)
