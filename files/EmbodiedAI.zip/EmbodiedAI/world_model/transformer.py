"""
world_model/transformer.py — the imagination module (Generation 2).

A causal transformer over interleaved (latent, action) tokens:
    z_1, a_1, z_2, a_2, ... -> predicts z_{t+1} from everything before it.

Trained jointly with the CNN encoder on prediction:
    loss = MSE( predict(z_t, a_t), sg(encode(o_{t+1})) ) + variance regulariser
The stop-gradient target + variance term (VICReg-style) prevents the trivial
collapse where the encoder maps every image to the same latent.

Also exposes:
    rollout(z0, actions)     — imagine a future without touching the simulator
    prediction_error(z_pred, z_real)  — the surprise signal driving the
                                        self-improvement loop
"""

from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F


class TransformerWorldModel(nn.Module):
    def __init__(self, latent_dim: int = 128, n_actions: int = 10,
                 d_model: int = 128, n_layers: int = 3, n_heads: int = 4,
                 context: int = 8):
        super().__init__()
        self.latent_dim = latent_dim
        self.context = context
        self.z_proj = nn.Linear(latent_dim, d_model)
        self.a_emb = nn.Embedding(n_actions, d_model)
        self.pos = nn.Parameter(torch.zeros(2 * context, d_model))
        layer = nn.TransformerEncoderLayer(
            d_model, n_heads, dim_feedforward=4 * d_model,
            batch_first=True, norm_first=True)
        self.tf = nn.TransformerEncoder(layer, n_layers)
        self.head = nn.Linear(d_model, latent_dim)

    def forward(self, z_seq: torch.Tensor, a_seq: torch.Tensor) -> torch.Tensor:
        """z_seq: (B, T, latent)  a_seq: (B, T) -> predicted z at each t+1: (B, T, latent)."""
        B, T, _ = z_seq.shape
        toks = torch.empty(B, 2 * T, self.z_proj.out_features,
                           device=z_seq.device)
        toks[:, 0::2] = self.z_proj(z_seq)
        toks[:, 1::2] = self.a_emb(a_seq)
        toks = toks + self.pos[: 2 * T]
        mask = torch.triu(torch.ones(2 * T, 2 * T, device=z_seq.device,
                                     dtype=torch.bool), diagonal=1)
        h = self.tf(toks, mask=mask)
        return self.head(h[:, 1::2])          # prediction after each action token

    @torch.no_grad()
    def rollout(self, z0: torch.Tensor, actions: list[int]) -> torch.Tensor:
        """Imagine: start latent (latent,) + action list -> (len+1, latent)."""
        z_seq = z0.reshape(1, 1, -1)
        a_hist = []
        outs = [z0]
        for a in actions:
            a_hist.append(a)
            a_t = torch.tensor([a_hist[-self.context:]], device=z0.device)
            zs = z_seq[:, -self.context:]
            pred = self.forward(zs, a_t)[:, -1]
            outs.append(pred[0])
            z_seq = torch.cat([z_seq, pred.reshape(1, 1, -1)], dim=1)
        return torch.stack(outs)


def prediction_error(z_pred: torch.Tensor, z_real: torch.Tensor) -> torch.Tensor:
    """Normalised surprise in [0, ~1+]: cosine distance between latents."""
    return 1.0 - F.cosine_similarity(z_pred, z_real, dim=-1)


def world_model_loss(z_pred: torch.Tensor, z_target: torch.Tensor,
                     z_all: torch.Tensor) -> tuple:
    """MSE to stop-grad targets + variance regulariser on the latent batch."""
    mse = F.mse_loss(z_pred, z_target.detach())
    std = z_all.std(dim=0)
    var_reg = F.relu(1.0 - std).mean()        # keep every latent dim alive
    return mse + 0.5 * var_reg, mse, var_reg
