# EmbodiedAI — Object Function Discovery from Primitive Actions

**Research question:** *Can an embodied agent discover object functions and solve
unseen tasks using only primitive actions, interaction experience, and intrinsic
drives, without explicit affordance labels?*

There is no module anywhere in this codebase that says `chair = ladder` or
`movable = True`. Object categories, affordances, and multi-step strategies must
emerge from interaction.

---

## The three generations

| Generation | Question it answers | Status |
|---|---|---|
| **Gen 1 — Rule-free exploration** | Can the robot build useful interaction memories? | ✅ implemented & validated |
| **Gen 2 — World dynamics** | Can the robot predict consequences of actions? | ✅ implemented & trained |
| **Gen 3 — Object Function Generator** | Can function embeddings emerge without labels? | 🔬 scaffold + eval protocol |

---

## Design contract

1. **Only primitive actions exist.** `forward, backward, rotate_left,
   rotate_right, push, pull, grab, release, wait, observe`. No `open_door`, no
   `use_key`, no `use_chair` anywhere in the environment API.
2. **Hidden physics.** Every object has mass, friction, size and special
   behaviour living *only inside the physics engine*. The agent never reads them.
3. **Label-free observations.**
   ```python
   obs = {"rgb": (96,96,3) uint8,   # egocentric camera
          "depth": (64,) float,      # 180° ray fan, normalised
          "robot_pose": (x, y, θ),
          "energy": 85.0, "time": 120, "inventory": []}
   ```
4. **Emergent mechanisms** the agent must discover through interaction:

   | Mechanism | Hidden rule |
   |---|---|
   | Locked door | `push` while a key is in inventory → unlocks (key consumed) |
   | Switch | *any* body touching it (robot **or a pushed object**) opens its door |
   | Pressure plate | any object with mass > 2 resting on it opens its door |
   | Ramp | robot inside the zone moves 1.6× faster |
   | Battery | `grab` → +40 energy |

---

## Architecture

```
Warehouse Simulator (pymunk / hidden physics)
        │  rgb + depth + proprioception (NO labels)
        ▼
   ConvEncoder  ──►  128-d latent      [perception/cnn.py]
        │                     (swap for DINOv3 later: same interface)
        ├──────────────┬──────────────────┐
        ▼              ▼                  ▼
 Transformer      Experience         Replay Buffer
 World Model       Memory            [memory/]
 [world_model/]   (SQLite + vec index)
        │              │
        └──────┬───────┘
               ▼
     Object Function Learner   [function_learning/]   ◄── Gen 3 contribution
               │
               ▼
        MCTS Planner  [planner/]
               │
               ▼
          Execute primitive → store new experience
```

---

## Quick start

```bash
pip install pymunk torch numpy pillow imageio

python main.py explore --episodes 8      # Gen 1: fill memory + replay buffer
python main.py train   --steps 250       # Gen 2: train world model
python main.py functions --steps 300     # Gen 3: train function encoder
python main.py plan    --level 1         # MCTS on benchmark level 1
python main.py demo                      # render an exploration GIF
python -m evaluation.run_benchmark       # full policy comparison
```

---

## Benchmark levels

| Level | Challenge | Requires |
|---|---|---|
| L1 | Reach the battery, doors open | navigation |
| L2 | Both doors locked, key available | **detour**: fetch key → return → push door |
| L3 | Key hidden under a box | push box → grab key → open door |
| L4 | No key; a switch opens one door | **tool/mechanism discovery** |
| L5 | Never-seen warehouse layout | generalization |

All five are **verified solvable** by a scripted oracle
(`evaluation/oracle.py`, ground-truth positions, validation only — never a
baseline for results). This matters: it proves that a learning agent's failure
is a planning/representation limitation, not a broken environment.

---

## Results so far (3 seeds, 700-step cap)

Generation-1 MCTS plans with ground-truth simulator rollouts and
distance-progress shaping.

- **L1, L5 (pure navigation): solved.**
- **L2, L3, L4: fail.** Greedy shaped search cannot commit to a *detour* —
  walking away from the goal to fetch a key looks strictly bad under distance
  shaping, so the search never discovers that the key unlocks the door.

**This negative result is the motivation for Generation 3.** The gap between
"can navigate" and "can use an object as a means to an end" is exactly the gap a
learned object-function representation is supposed to close. Any claimed Gen-3
contribution must be measured as improvement on L2–L4 over this Gen-1 baseline.

### Full policy comparison

| Policy | L1 | L2 | L3 | L4 | L5 |
|---|---|---|---|---|---|
| Random | 0% | 0% | 0% | 0% | 0% |
| Curious explorer | 0% | 0% | 0% | 0% | 0% |
| **MCTS (Gen 1)** | **100%** | **0%** | **0%** | **0%** | **100%** |
| Oracle *(validation only)* | 100% | 67% | 67% | 100% | 100% |

### Gen-3 objective ablation (3 seeds, 186 interaction records, 13 objects)

Does an unlabelled function embedding recover the hidden object kinds?
Scored as same-kind nearest-neighbour agreement. **Ceiling = 10/13**, because
three kinds have only one instance in the dataset and can never have a
same-kind neighbour.

| Objective | Score | % of ceiling |
|---|---|---|
| Random init (untrained) | 2.0/13 | 20% |
| **Predictive bottleneck** | **2.7/13** | **27%** |
| Contrastive (InfoNCE) | 1.3/13 | 13% |

**Honest reading: at this data scale, no objective produces reliable function
structure — the differences are within seed noise.** Two findings are still
meaningful:

1. **Instance-contrastive learning scores *below random initialisation*.** This
   is not noise but a predictable failure: InfoNCE pushes every object apart,
   including `chair_0` from `chair_1`. It learns object *identity*, which is the
   opposite of function. Do not use it for affordance discovery.
2. **The predictive bottleneck is the right shape of objective** — forcing
   `f_X` to predict held-out interaction outcomes means the embedding only needs
   to carry the object's action-response profile. It is directionally best, but
   needs far more data to prove itself.

**The bottleneck is interaction volume, not architecture.** 186 records over 13
objects is ~14 interactions each. Before drawing any Gen-3 conclusion, scale
exploration to 10^4–10^5 interaction records.

### World model (Gen 2)
Joint CNN + causal transformer training reduced prediction MSE **1.59 → 0.05**
over 250 steps with no latent collapse (variance regulariser active).

⚠️ **Honest caveat:** the copy-last-frame baseline is very strong at 1-step
prediction because consecutive frames barely differ. Report **multi-step
rollout error**, not 1-step MSE, as the headline world-model metric.

---

## Evidence that hidden physics leaks into experience

After 8 exploration episodes, mean displacement per `push` (agent never saw any
mass value):

| Object | Hidden mass | Mean displacement |
|---|---|---|
| key | 0.2 | 149.4 px |
| box | 2.5 | ~6–10 px |
| chair | 6.0 | ~3 px |
| table | 24.0 | ~1 px |
| shelf / door | static | 0.0 px |

The affordance ordering is already recoverable from raw interaction records —
this is the signal `FunctionEncoder` is trained to compress.

---

## Layout

```
EmbodiedAI/
├── env/          warehouse.py  physics.py  objects.py
├── perception/   cnn.py                     (→ DINOv3 later)
├── memory/       experience.py  replay_buffer.py
├── world_model/  transformer.py
├── function_learning/ function_encoder.py   ← Gen 3
├── planner/      mcts.py  planner.py
├── training/     train_world_model.py  train_function_model.py
├── evaluation/   benchmark.py  oracle.py  run_benchmark.py
└── main.py
```

## Next steps

0. **Scale interaction data first** — every Gen-3 conclusion is currently
   data-starved. Target 10^4+ interaction records before trusting any
   function-embedding result.
1. **Close the L2–L4 gap** — this is the thesis. Options: goal-conditioned
   function embeddings in the planner's scoring, subgoal discovery from
   experience clusters, or intrinsic reward for prediction-error reduction.
2. **Multi-step world-model rollouts** in the planner (replace simulator
   rollouts with imagination) — then report imagination-vs-reality drift.
3. **Function-embedding clustering evaluation** — do unlabelled embeddings
   recover the hidden object kinds? (`train_function_model.py` reports
   nearest-neighbour kind agreement.)
4. **Swap ConvEncoder → DINOv3**, `VectorIndex` → FAISS, pymunk → Isaac Lab.
   All three are drop-in: the interfaces were written for it.
