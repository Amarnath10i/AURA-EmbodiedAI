"""
training/train_world_model.py — Generation 2 training.

Jointly trains ConvEncoder + TransformerWorldModel on replay data:
    encode o_t -> z_t ;  predict z~_{t+1} from (z_{t-k..t}, a_{t-k..t})
    loss = MSE(z~_{t+1}, sg(z_{t+1})) + variance regulariser

Reports the metric that matters: prediction MSE vs the "lazy" baseline that
predicts z_{t+1} = z_t (copy-last-frame). Beating it means the model has
learned action-conditional dynamics, not just image similarity.

Usage:
    python -m training.train_world_model --data data/replay.npz --steps 400
"""

from __future__ import annotations
import argparse
import numpy as np
import torch

from perception.cnn import ConvEncoder, LATENT_DIM
from world_model.transformer import TransformerWorldModel, world_model_loss
from memory.replay_buffer import ReplayBuffer


def sample_sequences(data: dict, batch: int, ctx: int, rng):
    """(B, ctx+1) frame windows inside episodes + (B, ctx) actions."""
    ep = data["episode"]
    n = len(ep)
    starts = []
    while len(starts) < batch:
        i = int(rng.integers(0, n - ctx - 1))
        if (ep[i:i + ctx + 1] == ep[i]).all():
            starts.append(i)
    idx = np.array(starts)
    frames = np.stack([data["rgb"][i:i + ctx + 1] for i in idx])     # (B,ctx+1,H,W,3)
    actions = np.stack([data["action"][i:i + ctx] for i in idx])     # (B,ctx)
    return frames, actions


def train(data_path: str, steps: int = 400, batch: int = 32, ctx: int = 4,
          lr: float = 3e-4, seed: int = 0, out: str = "checkpoints"):
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    data = ReplayBuffer.load(data_path)
    n_val = max(64, int(0.1 * len(data["action"])))
    print(f"loaded {len(data['action'])} transitions from {data_path}")

    enc = ConvEncoder()
    wm = TransformerWorldModel(latent_dim=LATENT_DIM, context=ctx)
    opt = torch.optim.Adam(list(enc.parameters()) + list(wm.parameters()), lr=lr)

    def batch_loss(frames, actions, train_mode=True):
        B, T1 = frames.shape[:2]
        fl = torch.from_numpy(frames.reshape(-1, *frames.shape[2:]))
        z = enc(fl).reshape(B, T1, -1)                    # (B, ctx+1, D)
        a = torch.from_numpy(actions.astype(np.int64))
        z_pred = wm(z[:, :-1], a)                         # predict z_1..z_ctx
        loss, mse, var = world_model_loss(
            z_pred[:, -1], z[:, -1], z.reshape(-1, z.shape[-1]))
        # lazy baseline: predict z_{t+1} = z_t
        with torch.no_grad():
            lazy = torch.nn.functional.mse_loss(z[:, -2], z[:, -1])
        return loss, mse, var, lazy

    log = []
    for step in range(steps):
        frames, actions = sample_sequences(data, batch, ctx, rng)
        loss, mse, var, lazy = batch_loss(frames, actions)
        opt.zero_grad()
        loss.backward()
        opt.step()
        if step % 25 == 0 or step == steps - 1:
            log.append((step, float(mse), float(lazy)))
            print(f"step {step:4d}  pred_mse {mse:.4f}  lazy_baseline {lazy:.4f}"
                  f"  var_reg {var:.4f}")

    import os
    os.makedirs(out, exist_ok=True)
    torch.save({"encoder": enc.state_dict(), "world_model": wm.state_dict()},
               f"{out}/world_model.pt")
    print(f"saved {out}/world_model.pt")
    return log


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/replay.npz")
    p.add_argument("--steps", type=int, default=400)
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--ctx", type=int, default=4)
    p.add_argument("--seed", type=int, default=0)
    a = p.parse_args()
    train(a.data, a.steps, a.batch, a.ctx, seed=a.seed)
