"""
training/train_function_predictive.py — Generation 3, predictive objective.

Trains FunctionEncoder through a predictive bottleneck instead of instance
discrimination:  f_X = Enc(context experiences of X);  predict the outcome of a
HELD-OUT interaction with X from (f_X, action).

Evaluation: does the embedding space recover the hidden object kinds the agent
was never told?  Reported against the achievable ceiling, since singleton kinds
(only one instance in the dataset) can never have a same-kind neighbour.

Usage:  python -m training.train_function_predictive --steps 600
"""
from __future__ import annotations
import argparse, os
from collections import defaultdict

import numpy as np
import torch
import torch.nn.functional as F

from memory.experience import ExperienceMemory
from function_learning.function_encoder import (
    FunctionEncoder, FunctionPredictor, experiences_to_tensor, outcome_targets)


def load_histories(db_path: str, min_exp: int = 3):
    mem = ExperienceMemory(db_path)
    per = defaultdict(list)
    for r in mem.query():
        per[r["object_id"]].append(r)
    return {k: v for k, v in per.items() if len(v) >= min_exp}


def evaluate(model, hist, oids):
    """Nearest-neighbour kind agreement vs the achievable ceiling."""
    model.eval()
    with torch.no_grad():
        embs = []
        for oid in oids:
            x, m = experiences_to_tensor(hist[oid])
            embs.append(model(x[None], m[None])[0])
        E = torch.stack(embs)
    kinds = [o.rsplit("_", 1)[0] for o in oids]
    counts = defaultdict(int)
    for k in kinds:
        counts[k] += 1
    ceiling = sum(1 for k in kinds if counts[k] >= 2)

    sim = E @ E.T
    sim.fill_diagonal_(-1e9)
    correct = sum(int(kinds[int(sim[i].argmax())] == kinds[i])
                  for i in range(len(oids)))
    model.train()
    return correct, ceiling, len(oids)


def train(db_path="experience.db", steps=600, batch=10, lr=1e-3, seed=0):
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    hist = load_histories(db_path)
    oids = sorted(hist)
    print(f"objects: {len(oids)}  records: {sum(len(v) for v in hist.values())}")
    if len(oids) < 4:
        print("not enough objects — explore more first"); return

    enc = FunctionEncoder()
    head = FunctionPredictor()
    opt = torch.optim.Adam(list(enc.parameters()) + list(head.parameters()), lr=lr)

    c0, ceil0, n0 = evaluate(enc, hist, oids)
    print(f"before training: kind agreement {c0}/{n0} (ceiling {ceil0}/{n0})")

    for step in range(steps):
        chosen = rng.choice(oids, size=min(batch, len(oids)), replace=False)
        ctx, masks, acts, tgts = [], [], [], []
        for oid in chosen:
            rs = list(hist[oid]); rng.shuffle(rs)
            query = rs[0]                       # held-out interaction
            context = rs[1:]                    # everything else describes X
            x, m = experiences_to_tensor(context)
            ctx.append(x); masks.append(m)
            acts.append(int(query["action"]))
            tgts.append(outcome_targets([query])[0])
        f = enc(torch.stack(ctx), torch.stack(masks))
        pred = head(f, torch.tensor(acts))
        tgt = torch.stack(tgts)
        loss = F.mse_loss(pred[:, 0], tgt[:, 0]) + \
               F.binary_cross_entropy_with_logits(pred[:, 1], tgt[:, 1])
        opt.zero_grad(); loss.backward(); opt.step()
        if step % 100 == 0 or step == steps - 1:
            c, ceil, n = evaluate(enc, hist, oids)
            print(f"step {step:4d}  loss {float(loss):.4f}  "
                  f"kind agreement {c}/{n} (ceiling {ceil})")

    c, ceil, n = evaluate(enc, hist, oids)
    pct = 100 * c / max(ceil, 1)
    print(f"\nFINAL: {c}/{n} objects have a same-kind nearest neighbour")
    print(f"       ceiling {ceil}/{n} (singleton kinds cannot match)")
    print(f"       => {pct:.0f}% of achievable — ground truth used for EVAL ONLY")
    os.makedirs("checkpoints", exist_ok=True)
    torch.save({"encoder": enc.state_dict(), "head": head.state_dict()},
               "checkpoints/function_predictive.pt")
    return c, ceil, n


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--db", default="experience.db")
    p.add_argument("--steps", type=int, default=600)
    p.add_argument("--seed", type=int, default=0)
    a = p.parse_args()
    train(a.db, a.steps, seed=a.seed)
