"""
training/train_function_model.py — Generation 3 scaffold.

Trains the FunctionEncoder contrastively: two disjoint halves of one object's
experience history must embed close; other objects are negatives.

Evaluation (the honest test): cluster the learned function embeddings and
measure agreement with ground-truth object kinds that the simulator knows but
NEVER revealed to the agent. High agreement = affordance structure emerged
from interaction alone.

Usage:
    python -m training.train_function_model --db experience.db --steps 300
"""

from __future__ import annotations
import argparse
from collections import defaultdict

import numpy as np
import torch

from memory.experience import ExperienceMemory
from function_learning.function_encoder import (
    FunctionEncoder, info_nce, experiences_to_tensor)


def load_object_histories(db_path: str, min_exp: int = 3):
    mem = ExperienceMemory(db_path)
    rows = mem.query()
    per_object = defaultdict(list)
    for r in rows:
        per_object[r["object_id"]].append(r)
    return {oid: rs for oid, rs in per_object.items() if len(rs) >= min_exp}


def train(db_path: str, steps: int = 300, batch: int = 8, lr: float = 1e-3,
          seed: int = 0):
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    hist = load_object_histories(db_path)
    oids = list(hist)
    if len(oids) < 4:
        print(f"only {len(oids)} objects with enough experience — explore more first")
        return None
    print(f"training on interaction histories of {len(oids)} objects")

    model = FunctionEncoder()
    opt = torch.optim.Adam(model.parameters(), lr=lr)

    for step in range(steps):
        chosen = rng.choice(oids, size=min(batch, len(oids)), replace=False)
        a_batch, p_batch, a_mask, p_mask = [], [], [], []
        for oid in chosen:
            rs = list(hist[oid])
            rng.shuffle(rs)
            half = max(1, len(rs) // 2)
            xa, ma = experiences_to_tensor(rs[:half])
            xp, mp = experiences_to_tensor(rs[half:])
            a_batch.append(xa); p_batch.append(xp)
            a_mask.append(ma); p_mask.append(mp)
        za = model(torch.stack(a_batch), torch.stack(a_mask))
        zp = model(torch.stack(p_batch), torch.stack(p_mask))
        loss = info_nce(za, zp)
        opt.zero_grad(); loss.backward(); opt.step()
        if step % 50 == 0 or step == steps - 1:
            print(f"step {step:4d}  info_nce {float(loss):.3f}")

    # --- evaluation: do embeddings recover hidden object kinds? ---
    with torch.no_grad():
        embs, kinds = [], []
        for oid in oids:
            x, m = experiences_to_tensor(hist[oid])
            embs.append(model(x[None], m[None])[0])
            kinds.append(oid.rsplit("_", 1)[0])
        E = torch.stack(embs)
        sim = E @ E.T
        correct = total = 0
        for i, k in enumerate(kinds):
            j = int(sim[i].topk(2).indices[1])       # nearest other object
            correct += int(kinds[j] == k)
            total += 1
        print(f"nearest-neighbour kind agreement: {correct}/{total} "
              f"({100 * correct / max(total, 1):.0f}%) — sim ground truth used "
              f"for EVALUATION ONLY")
    torch.save(model.state_dict(), "checkpoints/function_encoder.pt")
    return model


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--db", default="experience.db")
    p.add_argument("--steps", type=int, default=300)
    a = p.parse_args()
    import os
    os.makedirs("checkpoints", exist_ok=True)
    train(a.db, a.steps)
